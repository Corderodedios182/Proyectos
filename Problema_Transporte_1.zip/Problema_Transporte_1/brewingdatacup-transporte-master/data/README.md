# Data Dictionary
![](https://i.imgur.com/1tdv5Sh.png)
